package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.options;

/**
 * Created by Mhr on 10/2/2015.
 */
public enum PTWStatus {
    NEW, APPROVED
}
