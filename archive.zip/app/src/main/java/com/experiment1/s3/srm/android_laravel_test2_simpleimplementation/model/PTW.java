package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by Mhr on 10/2/2015.
 */
public class PTW {
    //todo change name to permit
    public int id;
    public String workDescription;
    public String location;
    public String startTime;
    public String endTime;

    public String appliedDate;
    public String contractor;

    public int ptwType;
    public String status;




}
