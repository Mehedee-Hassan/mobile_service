package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by Mhr on 10/5/2015.
 */
public class PermitTemplateDetails {

    public int id;
    public String question;
    public String extra_text;
    public int sno;
    public int permit_template_id;


}
