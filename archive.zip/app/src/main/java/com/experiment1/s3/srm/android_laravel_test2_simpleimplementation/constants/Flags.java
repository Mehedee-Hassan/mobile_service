package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.constants;

/**
 * Created by Mhr on 9/23/2015.
 */
public class Flags {

    //{=0 no state
    //=1 true
    //=2 false
    //todo temporarily not used [delete]

    public static int tokenReceiveSuccessFlag = 0;
    //}

    public static boolean SAVE_CREDENTIAL_FLAG = false; // default don't save credential


    public static boolean LOGIN_SUCCESS_FLAG = false; //default
}
