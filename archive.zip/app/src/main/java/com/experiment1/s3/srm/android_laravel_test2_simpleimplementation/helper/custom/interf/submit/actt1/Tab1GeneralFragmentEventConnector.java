package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.helper.custom.interf.submit.actt1;

import com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.Permit;
import com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.view.GeneralTabSubmitAct;

/**
 * Created by User-8.1 on 10/12/2015.
 */
public interface Tab1GeneralFragmentEventConnector {

public Permit onSubmitButtonClick();

}
