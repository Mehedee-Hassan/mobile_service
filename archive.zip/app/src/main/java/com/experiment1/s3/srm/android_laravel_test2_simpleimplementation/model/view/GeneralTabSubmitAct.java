package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.view;

/**
 * Created by User-8.1 on 10/14/2015.
 */
public class GeneralTabSubmitAct {

}
