package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by Mhr on 9/22/2015.
 */
public class Token {

    public String access_token;
    public String token_type;
    public int expires_in;
//    public String refresh_token;


}
