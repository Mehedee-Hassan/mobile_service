package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.helper.custom.interf.submit.actt1;

import com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.PermitDetails;

import java.util.List;

/**
 * Created by User-8.1 on 10/19/2015.
 */
public interface Tab2CheckListFragmentEventConnector {


    public List<PermitDetails> onSubmitButtonClick();

}
