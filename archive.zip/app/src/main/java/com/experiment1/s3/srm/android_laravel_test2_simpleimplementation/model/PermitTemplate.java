package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by Mhr on 10/1/2015.
 */
public class PermitTemplate {
    public  int id; // id  =  server id ( loaded )
    public  String name;
    public  int company_id;
}
