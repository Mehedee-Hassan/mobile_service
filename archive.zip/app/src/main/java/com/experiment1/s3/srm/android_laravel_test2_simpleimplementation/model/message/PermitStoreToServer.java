package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.message;

/**
 * Created by User-8.1 on 10/13/2015.
 */
public class PermitStoreToServer {
    public String message;

    public int permit_id_at_server;
}
