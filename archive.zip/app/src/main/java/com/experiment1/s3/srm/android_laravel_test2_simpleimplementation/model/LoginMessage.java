package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by Mhr on 9/23/2015.
 */
public class LoginMessage {

    public String message;
    public int user_role;
    public int user_id;

}
