package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.helper.custom.interf.submit.actt3.dialog.usert2;

import com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.Permit;

/**
 * Created by Mhr on 10/8/2015.
 */
public interface UserTextChange {

    public void onChangeTextInEditText(CharSequence charSequence);

}
