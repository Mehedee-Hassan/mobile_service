package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model;

/**
 * Created by User-8.1 on 10/20/2015.
 */
public class PermitPermission {
    public int id;
    public int user_id;
    public long permit_id;
    public String status;



}
