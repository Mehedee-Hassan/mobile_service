package com.experiment1.s3.srm.android_laravel_test2_simpleimplementation.model.view;

/**
 * Created by Mhr on 10/2/2015.
 */
public class PTWForView {

    public String rowTextTitle ;
    public String rowTextTime ;
    public String rowTextDescription ;
    public String rowTextLocation ;

}
